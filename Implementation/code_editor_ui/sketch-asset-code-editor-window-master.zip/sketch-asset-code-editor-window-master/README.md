# Sketch Asset - Code Editor Window

A design resource file for [Sketch 3](http://www.bohemiancoding.com/sketch)

![](lib/dark-code-editor-window.png?raw=true)
